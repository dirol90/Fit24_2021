package com.dexterous.flutterlocalnotifications.utils;

public class BooleanUtils {
    public static boolean getValue(Boolean booleanObject){
        return booleanObject != null && booleanObject.booleanValue();
    }
}
